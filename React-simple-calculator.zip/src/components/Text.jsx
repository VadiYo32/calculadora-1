function Text() {
  return <p>bye world</p>;
}

export default Text;
